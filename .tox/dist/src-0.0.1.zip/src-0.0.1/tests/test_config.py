def test_fun():
    a=10
    b=20
    assert a+10==b

def test_fun_fun():
    assert 2==2